<?php
$txt = "Dan Badan";
echo "I love $txt!";
?>
