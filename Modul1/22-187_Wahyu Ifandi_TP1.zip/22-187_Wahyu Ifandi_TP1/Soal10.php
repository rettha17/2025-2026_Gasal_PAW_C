<?php
echo strrev("Hello world!"); 
// Output: !dlrow olleH
?>
