<?php
$x = 5;
$txt = "Hello world!";
$y = 10.5;

echo $txt . "<br>";
echo "Nilai x = " . $x . "<br>";
echo "Nilai y = " . $y;
?>
