<?php
$x = 20;
$y = 35;
echo $x + $y;
?>
