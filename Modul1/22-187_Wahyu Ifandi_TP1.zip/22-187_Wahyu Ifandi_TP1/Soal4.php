<!DOCTYPE html>
<html>
<body>

<?php
$color = "red";
echo "My car is " . $color . "<br>";
echo "My house is " . $COLOR . "<br>"; // Notice case-sensitive
echo "My boat is " . $coLOR . "<br>";
?>

</body>
</html>
