<!DOCTYPE html>
<html>
<head>
<title>Biodata</title>
</head>
<body>
<h2>Biodata Saya</h2>
<table border="1" cellpadding="5" cellspacing="0">
  <tr>
    <td>Nama</td>
    <td>Wahyu Ifandi</td>
  </tr>
  <tr>
    <td>NIM</td>
    <td>220411100187</td>
  </tr>
  <tr>
    <td>Alamat</td>
    <td>Ds,Jambu Burneh Bangklan</td>
  </tr>
  <tr>
    <td>Hobi</td>
    <td>Gak Ada Hobi</td>
  </tr>
</table>
</body>
</html>
