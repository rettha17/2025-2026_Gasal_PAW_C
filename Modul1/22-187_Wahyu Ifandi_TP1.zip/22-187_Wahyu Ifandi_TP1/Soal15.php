<?php
function familyName($fname, $year) {
  echo "$fname Refsnes. Born in $year <br>";
}

familyName("Stale", "1978");
familyName("Hege", "1975");
familyName("Kai Jim", "1983");
?>
