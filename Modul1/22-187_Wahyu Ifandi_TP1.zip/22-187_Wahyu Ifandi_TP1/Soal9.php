<?php
echo str_word_count("Hello world!"); 
// Output: 2
?>
