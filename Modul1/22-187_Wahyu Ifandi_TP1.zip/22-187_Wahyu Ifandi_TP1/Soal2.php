<!DOCTYPE html> <!-- Menentukan bahwa dokumen ini menggunakan HTML5 -->
<html>
    <body>
        <?php
        // echo adalah perintah PHP untuk menampilkan output ke browser
        // Dalam contoh ini, yang ditampilkan adalah teks "Halo Motak"
        echo "Halo Motak"; // Output di browser: Halo Motak
        ?>
    </body>
</html>
