<?php
echo strlen("Hello world!"); 
// Output: 12
?>
