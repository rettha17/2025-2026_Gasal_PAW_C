<?php
echo strpos("Hello world!", "world"); 
// Output: 6 (karena 'world' dimulai di posisi ke-6, index dihitung dari 0)
?>
