<?php
echo str_word_count("Hello world!"); // outputs 2
?>
