<!DOCTYPE html>
<html>
<body>

<?php
echo "Hello world";
?>

</body>
</html>
